import { useParams, useLocation } from 'react-router-dom';
import useCatalogData from '../../../hooks/useCatalogData';
import ProductsList from './ProductsList';
import { useTranslation } from 'react-i18next';
import { useOutletContext } from 'react-router-dom';

const ProductsPage = () => {
  const { t } = useTranslation();
  const { categorySlug, subcategorySlug } = useParams();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const searchQuery = queryParams.get('query') || '';
  const context = useOutletContext();
  const query = context?.query || searchQuery;
  const filters = context?.filters || location.state?.filters || {};
  const sortOption = context?.sortOption || location.state?.sortOption || { field: 'name', direction: 'asc' };
  const isSearchPage = location.pathname.startsWith('/search');

  const { data: products, loading, error } = useCatalogData(
    isSearchPage ? 'search' : 'products',
    isSearchPage
      ? { query }
      : { 
          category: categorySlug, 
          subcategory: subcategorySlug 
        }
  );

  if (loading) return <div className="loading"></div>;
  if (error) return <div className="error">{error.message}</div>;

  return (
    <>
      {isSearchPage && <h2>{t('search.result')}: {query}</h2>}
      <ProductsList
        products={products}
        emptyMessage={t('catalog.noProducts')}
        isSearchPage={isSearchPage}
        query={query}
        initialFilters={filters}
      />
    </>
  );
};

export default ProductsPage;