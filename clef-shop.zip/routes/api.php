<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\AdminCatalogController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\AdminMessageController;

use App\Http\Controllers\TranslationController;
use App\Http\Controllers\AdminUserController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\FileUploadController;
use App\Http\Controllers\ImageUploadController;
use App\Http\Controllers\AdminOrderController;



Route::middleware('auth:sanctum')->get('/user', [AuthController::class, 'user']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
Route::middleware('auth:sanctum')->put('/user/profile', [AuthController::class, 'updateProfile']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/cart', [CartController::class, 'index']);
    Route::post('/cart/add', [CartController::class, 'add']);
    Route::put('/cart/update', [CartController::class, 'update']);
    Route::delete('/cart/remove/{productId}', [CartController::class, 'removeItem']);
    Route::delete('/cart/clear', [CartController::class, 'clear']);
    Route::post('/cart/sync', [CartController::class, 'sync']);
});


Route::middleware('auth:sanctum')->group(function () {
    Route::get('/order', [OrderController::class, 'getOrder']);
    Route::post('/order/create', [OrderController::class, 'createOrder']);
    
    /*Route::put('/order/update', [CartController::class, 'updateOrder']);*/
});

Route::middleware('auth:sanctum')->group(function () {
    // Для пользователя
    Route::get('/messages', [MessageController::class, 'index']);
    Route::post('/messages', [MessageController::class, 'store']);
    
    // Для администратора
    Route::prefix('admin')->middleware('admin')->group(function () {
        Route::get('/conversations', [AdminMessageController::class, 'index']);
        Route::get('/conversations/{user}', [AdminMessageController::class, 'show']);
        Route::post('/conversations/{user}', [AdminMessageController::class, 'store']);
        Route::post('/conversations/{user}/mark-read', [AdminMessageController::class, 'markRead']);
    });
});

Route::get('/search', [SearchController::class, 'search'])
     ->name('search');

Route::get('/catalog/data', [CatalogController::class, 'fetchData'])
     ->name('catalog.data');
     Route::get('/catalog/last-updated', [CatalogController::class, 'lastUpdated'])
     ->name('catalog.last-updated');

Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
   
    // Управление пользователями
    Route::get('/users', [AdminUserController::class, 'getUsers']);
    Route::get('/users/{id}', [AdminUserController::class, 'getUser']);
    Route::post('/users', [AdminUserController::class, 'createUser']);
    Route::put('/users/{id}', [AdminUserController::class, 'updateUser']);
    Route::delete('/users/{id}', [AdminUserController::class, 'deleteUser']);
    Route::post('/catalog/import', [AdminCatalogController::class, 'import'])->name('admin.catalog.import');
        Route::get('/catalog/data', [AdminCatalogController::class, 'fetchData'])->name('admin.catalog.data');
        Route::post('/catalog', [AdminCatalogController::class, 'store'])->name('admin.catalog.store');
        Route::put('/catalog/{id}', [AdminCatalogController::class, 'update'])->name('admin.catalog.update');
        Route::post('/catalog/{id}', [AdminCatalogController::class, 'update'])->name('admin.catalog.update.post');
        Route::delete('/catalog/{id}', [AdminCatalogController::class, 'destroy'])->name('admin.catalog.destroy');
        Route::get('/catalog/spec-keys-values', [AdminCatalogController::class, 'getSpecKeysAndValues'])->name('admin.catalog.spec-keys-values'); 
        Route::get('/catalog/brands', [AdminCatalogController::class, 'getBrands'])->name('admin.catalog.brands');
        Route::post('/catalog/translations', [TranslationController::class, 'store'])->name('admin.catalog.translation');
        Route::get('/catalog/export', [AdminCatalogController::class, 'export'])->name('admin.catalog.export');
 
  

    Route::get('/pages', [PageController::class, 'index']);
    Route::put('/pages/{pageId}', [PageController::class, 'update']);
    //управление заказами
    Route::get('/orders', [AdminOrderController::class, 'index']);
    Route::delete('/orders/{orderId}', [AdminOrderController::class, 'destroy']);
    Route::put('orders/{orderId}', [AdminOrderController::class, 'update']);
    
    // Загрузка изображений
    Route::post('/upload-image', [ImageUploadController::class, 'uploadImage']);
    Route::delete('/delete-image', [ImageUploadController::class, 'deleteImage']);
    Route::get('/images', [ImageUploadController::class, 'getImages']);

    
});

// Маршруты только для супер админа
// Route::middleware(['auth:sanctum', 'super_admin'])->prefix('admin/super')->group(function () {
    
// });
// Публичные роуты для получения контента страниц
Route::get('/pages/{pageId}', [PageController::class, 'show']);






